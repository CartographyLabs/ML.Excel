# load library e1071 & caret - should be installed with R upon setup
library(e1071)
library(caret)

# Set directory for active kernel to Excel.ML installation
setwd("C:\\Program Files\\Excel.ML\\naiveBayes")

# Read form data saved from windows forms
formData <- read.csv("naiveBayesSciptInput.csv", stringsAsFactors = FALSE)
modelTrainConfig <- read.csv("nbConfig.csv", stringsAsFactors = FALSE)

class = modelTrainConfig$class[1]
classInd = which(colnames(formData) == class)
lp = modelTrainConfig$laplace[1]
trnDatPct = modelTrainConfig$percenttesting[1]
tstDatPct = modelTrainConfig$percenttraining[1]
seed = modelTrainConfig$seed[1]

# Set psuedo-random sampling seed
set.seed(seed)

# Split Train and Test Datasets
split <- sample(c(TRUE, FALSE), 
                nrow(formData), 
                replace=TRUE, 
                prob=c(trnDatPct, tstDatPct)
)

# Define Training Data and Class Vector
modelTrainData <- formData[split,]
modelTrainClassVector <- formData[split,classInd]

# Define Testing Data and Class Vector
modelTestData <- formData[!split,-classInd]
modelTestClassVector <- formData[!split,classInd]

# Train a naiveBayes model
nb <- naiveBayes(output ~ ., data = modelTrainData, laplace = lp, na.action = na.pass)

# Predict the test data classificaton
p <- predict(nb, modelTestData)

# Store Model Performance Data
cm <- confusionMatrix(table(p, modelTestClassVector))
cmCI <- cm$overall["95% CI"]
cmNIR <- cm$overall["No Information Rate"]
cmPVal <- cm$overall["P-Value [Acc > NIR]"]
cmKappa <- cm$overall["Kappa"]
cmMPVal <- cm$overall["Mcnemar's Test P-Value"]

ct <- as.numeric(table(p, modelTestClassVector))
TP <- ct[1]
TN <- ct[4]
FP <- ct[2]
FN <- ct[3]
totalObs <- TP + FP + TN + FN
cmAccuracy <- (TP + TN) / totalObs
cmSensitivity <- TP / (TP + FP)
cmSpecificity <- TN / (TN + FN)
cmPrevalence <- (TP + FP) / totalObs
cmPosPredValue <- (cmSensitivity * cmPrevalence) / ( (cmSensitivity * cmPrevalence) + ( (1-cmSpecificity) * (1-cmPrevalence) ) )
cmNegPredValue <- (cmSpecificity * (1-cmPrevalence)) / ( ( (1-cmSensitivity) * cmPrevalence ) + ( (cmSpecificity) * (1-cmPrevalence) ) )
cmPrecision <- TP / (TP + FN)
cmRecall <- TP / (TP + FP) # Same as Sensitivity
cmF1 <- 2 * ( (cmPrecision * cmRecall) / ((2 * cmPrecision) + cmRecall) )
cmDetectionRate <- TP / totalObs
cmDetectionPrevalence <- (TP + FN) / totalObs
cmBalancedAccuracy <- (cmSensitivity + cmSpecificity) / 2

results <- cbind(TP, TN, FP, FN,
                 cmAccuracy, 
                 cmCI, 
                 cmNIR,
                 cmPVal,
                 cmKappa,
                 cmMPVal,
                 cmSensitivity,
                 cmSpecificity,
                 cmPosPredValue,
                 cmNegPredValue,
                 cmPrecision,
                 cmRecall,
                 cmF1,
                 cmPrevalence,
                 cmDetectionRate,
                 cmDetectionPrevalence,
                 cmBalancedAccuracy
)

print(results)

write.csv(results, "ModelPerformance.csv")

# save naive bayes model via serialization interface

saveRDS(nb, "NBmodel.rds")