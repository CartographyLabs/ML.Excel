# load library e1071 & caret - should be installed with R upon setup
library(e1071)

# Set directory for active kernel to Excel.ML installation
setwd("C:\\Program Files\\Excel.ML\\naiveBayes")

# Read form data saved from windows forms
xlData <- read.csv("ExcelDataInput.csv")

# load naive bayes model via serialization interface
nb <- readRDS("NBmodel.rds")

# create prediction using Excel Data
p <- predict(xlData, nb)

# Write prediction back into csv to insert back into Excel.
write.csv(p, "ExcelDataOutput.csv")